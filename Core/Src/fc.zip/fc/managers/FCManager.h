
#ifndef SRC_FC_MANAGERS_FCMANAGER_H_
#define SRC_FC_MANAGERS_FCMANAGER_H_

#include <sys/_stdint.h>

uint8_t initFC(void);
void runFC(void);

#endif
