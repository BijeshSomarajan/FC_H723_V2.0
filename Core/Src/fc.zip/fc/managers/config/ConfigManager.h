#ifndef CONFIGURATIONMANAGER_H_
#define CONFIGURATIONMANAGER_H_

#include <stdint.h>


uint8_t initConfigManager(void);
void doConfigManagement(void);


#endif
