#include "AltitudeManager.h"

#include "../../control/altitude/AltitudeControl.h"
#include "../../control/ControlData.h"
#include "../../calibration/Calibration.h"

#include "../../imu/IMU.h"
#include "../../logger/Logger.h"
#include "../../memory/Memory.h"
#include "../../sensors/altitude/AltitudeSensor.h"
#include "../../sensors/altitude/devices/AltitudeDevice.h"
#include "../../sensors/rc/RCSensor.h"
#include "../../status/FCStatus.h"
#include "../../timers/DeltaTimer.h"
#include "../../timers/GPTimer.h"
#include "../../timers/Scheduler.h"
#include "../../util/MathUtil.h"
#include "../../FCConfig.h"

// Inner state variables
float altitudeUpdateDt = 0;

float altMgrThAltAggregationDt = 0;
float altMgrAltAggregationDt = 0;

float altMgrAltHoldActivationDt = 0;
float altStabilizationDt = 0;

float altMgrKIGain = 1.0f;
float altMgrKPGain = 1.0f;
float altMgrRateKPGain = 1.0f;
float altMgrRateKDGain = 1.0f;

float altMgrLiftOffThrottle = 0;
float altMgrLiftOffThrottlePercent = 0;
float altMgrSoftLiftOffThrottlePercent = 0;

float altMgrMaxSLAlt = 0;
float altMgrMaxGndAlt = 0;

uint8_t altitudeManagerWasInStabMode = 0;

void startAltitudeSensorsRead(void);
void manageAltitudeTask(void);

uint8_t initAltitudeManager(void) {
	logString("[Altitude Manager] Init > Start\n");
	uint8_t status = initAltitudeSensors();
	if (status) {
		logString("[Altitude Manager] Sensor Init > Success\n");
		startAltitudeSensorsRead();
		schedulerAddTask(manageAltitudeTask, ALTITUDE_MANAGEMENT_TASK_FREQUENCY, ALT_ESTIMATION_TASK_PRIORITY);
		logString("[Altitude Manager] All tasks   > Started\n");

		altMgrLiftOffThrottle = (float) getCalibrationValue(CALIB_PROP_RC_LIFTOFF_THROTTLE_ADDR);

		altMgrLiftOffThrottlePercent = altMgrLiftOffThrottle / (float) ALT_MGR_MAX_PERMISSIBLE_THROTTLE_DELTA;
		altMgrSoftLiftOffThrottlePercent = altMgrLiftOffThrottlePercent + ALT_MGR_SOFT_START_WINDOW_PERCENTAGE;

		fcStatusData.liftOffThrottlePercent = altMgrLiftOffThrottlePercent;

		altMgrMaxSLAlt = (float) getCalibrationValue(CALIB_PROP_ALT_HOLD_MAX_ASL_HEIGHT_ADDR);
		altMgrMaxGndAlt = (float) getCalibrationValue(CALIB_PROP_ALT_HOLD_MAX_TERRAIN_HEIGHT_ADDR);

		initAltitudeControl();

	} else {
		logString("[Altitude Manager] Init > Failed!\n");
	}
	return status;
}

__ATTR_ITCM_TEXT
void readBaroSensorTimerCallback() {
	readAltitudeSensors();
}

void startAltitudeSensorsRead() {
	initGPTimer3(BARO_SENSOR_READ_FREQUENCY, readBaroSensorTimerCallback, 4);
	startGPTimer3();
}

__ATTR_ITCM_TEXT
void aggregateThrottleAndAlt(float dt) {
	altMgrThAltAggregationDt += dt;
	if (altMgrThAltAggregationDt >= ALT_MGR_ALT_TH_AGGREGATION_PERIOD) {
		float thGain = ALT_MGR_PRE_LIFTOFF_TH_AGGREGATION_GAIN;
		float altGain = ALT_MGR_PRE_LIFTOFF_ALT_AGGREGATION_GAIN;

		if (fcStatusData.throttlePercentage >= altMgrLiftOffThrottlePercent) {
			thGain = ALT_MGR_POST_LIFTOFF_TH_AGGREGATION_GAIN;
			if (fcStatusData.throttlePercentage <= altMgrSoftLiftOffThrottlePercent) {
				altGain = ALT_MGR_SOFT_LIFTOFF_ALT_AGGREGATION_GAIN;
			} else {
				altGain = ALT_MGR_POST_LIFTOFF_ALT_AGGREGATION_GAIN;
			}
		}

		fcStatusData.currentThrottle += rcData.RC_EFFECTIVE_DATA[RC_TH_CHANNEL_INDEX] * thGain;
		fcStatusData.currentThrottle = constrainToRangeF(fcStatusData.currentThrottle, 0, ALT_MGR_MAX_PERMISSIBLE_THROTTLE_DELTA);
		fcStatusData.throttlePercentage = fcStatusData.currentThrottle / ALT_MGR_MAX_PERMISSIBLE_THROTTLE_DELTA;

		fcStatusData.throttleAltitudeRef += rcData.RC_EFFECTIVE_DATA[RC_TH_CHANNEL_INDEX] * altGain;
		fcStatusData.throttleAltitudeRef = constrainToRangeF(fcStatusData.throttleAltitudeRef, 0, fcStatusData.altitudeSLMax);

		fcStatusData.throttleAltitudeRate = (fcStatusData.throttleAltitudeRef - fcStatusData.previousThrottleAltitudeRef) * ALT_MGR_TH_ALT_RATE_GAIN;
		fcStatusData.throttleRate = (fcStatusData.currentThrottle - fcStatusData.previuosThrottle) * ALT_MGR_TH_RATE_GAIN;

		altMgrThAltAggregationDt = 0;
	}
}

__ATTR_ITCM_TEXT
void manageAltitude(float dt) {
	if (!rcData.throttleCentered) {
		aggregateThrottleAndAlt(dt);
	} else {
		fcStatusData.previousThrottleAltitudeRef = fcStatusData.throttleAltitudeRef;
		fcStatusData.previuosThrottle = fcStatusData.currentThrottle;
		fcStatusData.throttleAltitudeRate = 0;
		fcStatusData.throttleRate = 0;
	}
	if (fcStatusData.throttlePercentage <= altMgrLiftOffThrottlePercent) {
		controlData.throttleControl = fcStatusData.currentThrottle;
		fcStatusData.throttleAltitudeRef = sensorAltitudeData.altitudeSLFiltered;
		fcStatusData.altitudeSLRef = sensorAltitudeData.altitudeSLFiltered;
		fcStatusData.throttleAltitudeRate = 0;
		fcStatusData.throttleRate = 0;
		fcStatusData.altitudeHoldEnabled = 0;
		resetAltitudeControl(1);
	} else {
		controlData.throttleControl = altMgrLiftOffThrottle;
		fcStatusData.altitudeHoldEnabled = 1;
		controlAltitude(dt, fcStatusData.throttleAltitudeRef);
	}
}

__ATTR_ITCM_TEXT
void updateAltitudeRefernces() {
	fcStatusData.altitudeSLHome = sensorAltitudeData.altitudeSLFiltered;
	fcStatusData.altitudeSLRef = sensorAltitudeData.altitudeSLFiltered;
	fcStatusData.altitudeSLMax = fcStatusData.altitudeSLHome + altMgrMaxSLAlt;
	fcStatusData.altitudeGndMax = altMgrMaxGndAlt;
}

__ATTR_ITCM_TEXT
void manageAltitudeTask(void) {
	float dt = getDeltaTime(ALT_TIMER_CHANNEL);
	processAltitude(dt, 0);
	if (fcStatusData.canFly) {
		manageAltitude(dt);
	} else if (fcStatusData.canStabilize) {
		resetAltitudeControl(1);
		updateAltitudeRefernces();
		fcStatusData.throttlePercentage = 0;
		controlData.throttleControl = 0;
		fcStatusData.currentThrottle = 0;
		fcStatusData.previuosThrottle = 0;
		altMgrThAltAggregationDt = 0;
	}
}

__ATTR_ITCM_TEXT
void doAltitudeManagement(void) {
	if (!fcStatusData.isConfigMode) {
		if (fcStatusData.canStabilize) {
			fcStatusData.altitudeSLHome = sensorAltitudeData.altitudeSLFiltered;
			fcStatusData.altitudeSLRef = fcStatusData.altitudeSLHome;
			altitudeManagerWasInStabMode = 1;
		} else if (altitudeManagerWasInStabMode && fcStatusData.isStabilized) {
			altitudeManagerWasInStabMode = 0;
		}
		if (loadAltitudeSensorsData()) {
			float dt = getDeltaTime(SENSOR_BARO_READ_TIMER_CHANNEL);
			updateAltitude(dt);
		}
	}
}

void resetAltitudeManager(void) {
	resetAltitudeControl(1);
	resetAltitudeSensors(0);
}
