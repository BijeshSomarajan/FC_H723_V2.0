#include "DebugManager.h"

#include <sys/_stdint.h>

#include "../../control/ControlData.h"
#include "../../imu/IMU.h"
#include "../../sensors/altitude/AltitudeSensor.h"
#include "../../sensors/attitude/AttitudeSensor.h"
#include "../../sensors/attitude/AttitudeNoiseFilter.h"
#include "../../sensors/rc/RCSensor.h"
#include "../../status/FCStatus.h"
#include "../../timers/DeltaTimer.h"
#include "../../timers/Scheduler.h"
#include "../config/ConfigHelper.h"
#include "../../FCConfig.h"
#include "../output/OutputManager.h"
#include "../../dsp/BiQuadFilter.h"
#include "../../dsp/FFT.h"

#if DEBUG_ENABLED == 1

extern FFTContext fftContextGyroX;
extern FFTContext fftContextGyroY;
extern FFTContext fftContextGyroZ;

int32_t DEBUG_DATA_BUFFER[8];

void debugTask(void);

uint8_t initDebugManager(void) {
	schedulerAddTask(debugTask, DEBUG_FREQUENCY, DEBUG_TASK_PRIORITY);
	return 1;
}

void debugTime(float dt) {
	DEBUG_DATA_BUFFER[0] = 1.0f / (imuData.arhsDt == 0 ? 1 : imuData.arhsDt);
	DEBUG_DATA_BUFFER[1] = 1.0f / (sensorAttitudeData.agtDataUpdateDt == 0 ? 1 : sensorAttitudeData.agtDataUpdateDt);
	DEBUG_DATA_BUFFER[2] = 1.0f / (sensorAttitudeData.magDataUpdateDt == 0 ? 1 : sensorAttitudeData.magDataUpdateDt);
	DEBUG_DATA_BUFFER[3] = 1.0f / (sensorAttitudeData.noiseFilterProcessXDt == 0 ? 1 : sensorAttitudeData.noiseFilterProcessXDt);
	DEBUG_DATA_BUFFER[4] = 1.0f / (sensorAltitudeData.altDataUpdateDt == 0 ? 1 : sensorAltitudeData.altDataUpdateDt);
	DEBUG_DATA_BUFFER[5] = 1.0f / (rcData.updateDataDt == 0 ? 1 : rcData.updateDataDt);
	DEBUG_DATA_BUFFER[6] = 1.0f / (pwmData.updateDt == 0 ? 1 : pwmData.updateDt);
	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void debugImu(float dt) {
	DEBUG_DATA_BUFFER[0] = sensorAttitudeData.pitchRate * 10;
	DEBUG_DATA_BUFFER[1] = sensorAttitudeData.pitch * 10;
	DEBUG_DATA_BUFFER[2] = sensorAttitudeData.rollRate * 10;
	DEBUG_DATA_BUFFER[3] = sensorAttitudeData.roll * 10;
	DEBUG_DATA_BUFFER[4] = sensorAttitudeData.yawRate * 10;
	DEBUG_DATA_BUFFER[5] = sensorAttitudeData.heading;
	DEBUG_DATA_BUFFER[6] = controlData.pitchControl;
	DEBUG_DATA_BUFFER[7] = fcStatusData.throttlePercentage * 100;
	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void debugHeading(float dt) {
	DEBUG_DATA_BUFFER[0] = fcStatusData.headingDelta;
	DEBUG_DATA_BUFFER[1] = sensorAttitudeData.heading;
	DEBUG_DATA_BUFFER[2] = fcStatusData.headingRef;
	DEBUG_DATA_BUFFER[3] = controlData.yawControl;
	DEBUG_DATA_BUFFER[4] = fcStatusData.headingHomeRef;
	DEBUG_DATA_BUFFER[5] = fcStatusData.throttlePercentage * 100;
	sendConfigData(DEBUG_DATA_BUFFER, 6, CMD_FC_DATA);
}

void debugAttitude() {
	DEBUG_DATA_BUFFER[0] = imuData.linBodyVx * 1000;
	DEBUG_DATA_BUFFER[1] = imuData.linBodyVy * 1000;
	DEBUG_DATA_BUFFER[2] = imuData.linBodyVz * 1000;
	DEBUG_DATA_BUFFER[3] = sensorAttitudeData.pitch * 10;
	DEBUG_DATA_BUFFER[4] = sensorAttitudeData.roll * 10;
	DEBUG_DATA_BUFFER[5] = sensorAttitudeData.heading * 10;
	DEBUG_DATA_BUFFER[6] = sensorAltitudeData.altitudeSL * 10;
	sendConfigData(DEBUG_DATA_BUFFER, 7, CMD_FC_DATA);
}

void debugAltitude() {
	DEBUG_DATA_BUFFER[0] = sensorAltitudeData.altitudeSLEstimated - fcStatusData.altitudeSLHome;
	DEBUG_DATA_BUFFER[1] = sensorAltitudeData.altitudeSLFiltered - fcStatusData.altitudeSLHome;
	DEBUG_DATA_BUFFER[2] = sensorAltitudeData.verticalVelocity * 10;
	DEBUG_DATA_BUFFER[3] = imuData.linBodyVz * 1000;
	sendConfigData(DEBUG_DATA_BUFFER, 4, CMD_FC_DATA);
}

extern float altMgrLiftOffThrottlePercent;
void debugPWM() {
	DEBUG_DATA_BUFFER[0] = controlData.altitudeControl;
	DEBUG_DATA_BUFFER[1] = controlData.throttleControl + controlData.altitudeControl;
	DEBUG_DATA_BUFFER[2] = sensorAltitudeData.verticalVelocity * 10;
	DEBUG_DATA_BUFFER[3] = fcStatusData.currentThrottle;
	DEBUG_DATA_BUFFER[4] = fcStatusData.throttleAltitudeRef - fcStatusData.altitudeSLHome;
	DEBUG_DATA_BUFFER[5] = sensorAltitudeData.altitudeSLFiltered - fcStatusData.altitudeSLHome;
	DEBUG_DATA_BUFFER[6] = sensorAltitudeData.altitudeSLEstimated - fcStatusData.altitudeSLHome;
	DEBUG_DATA_BUFFER[7] = pwmData.PWM_VALUES[0];
	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void debugFFT() {
	/*
	 DEBUG_DATA_BUFFER[0] = sensorAttitudeData.gxDSFiltered * 10;
	 DEBUG_DATA_BUFFER[1] = sensorAttitudeData.gyDSFiltered * 10;
	 DEBUG_DATA_BUFFER[2] = sensorAttitudeData.gzDSFiltered * 10;
	 DEBUG_DATA_BUFFER[3] = sensorAttitudeData.axGFiltered * 1000;
	 DEBUG_DATA_BUFFER[4] = sensorAttitudeData.ayGFiltered * 1000;
	 DEBUG_DATA_BUFFER[5] = sensorAttitudeData.azGFiltered * 1000;
	 DEBUG_DATA_BUFFER[6] = imuData.pitch * 100;
	 DEBUG_DATA_BUFFER[7] = imuData.roll * 100;
	 */
	/*
	 DEBUG_DATA_BUFFER[6] = fftContextGyroX.topFreq[1];
	 DEBUG_DATA_BUFFER[7] = fftContextGyroX.topFreq[2];
	 */
	/*
	 DEBUG_DATA_BUFFER[0] = fftContextGyroX.fftMagnitudes[1] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[1] = fftContextGyroX.fftMagnitudes[2] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[2] = fftContextGyroX.fftMagnitudes[3] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[3] = fftContextGyroX.fftMagnitudes[4] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[4] = fftContextGyroX.fftMagnitudes[5] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[5] = fftContextGyroX.fftMagnitudes[6] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[6] = fftContextGyroX.fftMagnitudes[7] - fftContextGyroX.fftMagnitudes[0];
	 DEBUG_DATA_BUFFER[7] = fftContextGyroX.fftMagnitudes[8] - fftContextGyroX.fftMagnitudes[0];
	 */
	/*
	 DEBUG_DATA_BUFFER[0] = fftContextGyroX.topFreq[0];
	 DEBUG_DATA_BUFFER[1] = fftContextGyroX.topFreq[1];

	 DEBUG_DATA_BUFFER[2] = ( fftContextGyroX.fftMagnitudes[1] - fftContextGyroX.fftMagnitudes[0] ) * 10;
	 DEBUG_DATA_BUFFER[3] = ( fftContextGyroX.fftMagnitudes[2] - fftContextGyroX.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[4] = ( fftContextGyroX.fftMagnitudes[3] - fftContextGyroX.fftMagnitudes[0]) * 10;

	 DEBUG_DATA_BUFFER[5] = ( fftContextGyroY.fftMagnitudes[1] - fftContextGyroY.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[6] = ( fftContextGyroY.fftMagnitudes[2] - fftContextGyroY.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[7] = ( fftContextGyroY.fftMagnitudes[3] - fftContextGyroY.fftMagnitudes[0]) * 10;
	 */

	DEBUG_DATA_BUFFER[0] = fftContextGyroX.topFreq[0];
//	DEBUG_DATA_BUFFER[1] = fftContextGyroX.topFreq[1];
	//DEBUG_DATA_BUFFER[2] = fftContextGyroY.topFreq[2];

	DEBUG_DATA_BUFFER[2] = fftContextGyroY.topFreq[0];
//	DEBUG_DATA_BUFFER[3] = fftContextGyroY.topFreq[1];
//	DEBUG_DATA_BUFFER[5] = fftContextGyroX.topFreq[2];


	DEBUG_DATA_BUFFER[4] = fftContextGyroZ.topFreq[0];
//	DEBUG_DATA_BUFFER[5] = fftContextGyroZ.topFreq[1];

	/*
	DEBUG_DATA_BUFFER[6] = fftContextGyroY.noiseFloor * 10;
	DEBUG_DATA_BUFFER[7] = fftContextGyroX.noiseFloor * 10;
	*/

	/*
	 DEBUG_DATA_BUFFER[2] = (fftContextGyroX.fftMagnitudes[1] - fftContextGyroX.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[3] = (fftContextGyroX.fftMagnitudes[2] - fftContextGyroX.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[4] = (fftContextGyroX.fftMagnitudes[3] - fftContextGyroX.fftMagnitudes[0]) * 10;

	 DEBUG_DATA_BUFFER[5] = (fftContextGyroY.fftMagnitudes[1] - fftContextGyroY.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[6] = (fftContextGyroY.fftMagnitudes[2] - fftContextGyroY.fftMagnitudes[0]) * 10;
	 DEBUG_DATA_BUFFER[7] = (fftContextGyroY.fftMagnitudes[3] - fftContextGyroY.fftMagnitudes[0]) * 10;
	 */
	sendConfigData(DEBUG_DATA_BUFFER, 6, CMD_FC_DATA);
}

void debugRC() {
	DEBUG_DATA_BUFFER[0] = 1.0f / rcData.updateDataDt;
	DEBUG_DATA_BUFFER[1] = rcData.RC_DELTA_DATA[RC_TH_CHANNEL_INDEX];
	DEBUG_DATA_BUFFER[2] = rcData.RC_DELTA_DATA[RC_PITCH_CHANNEL_INDEX];
	DEBUG_DATA_BUFFER[3] = rcData.RC_DELTA_DATA[RC_ROLL_CHANNEL_INDEX];

	DEBUG_DATA_BUFFER[4] = fcStatusData.canArm;
	DEBUG_DATA_BUFFER[5] = fcStatusData.canStart;
	DEBUG_DATA_BUFFER[6] = fcStatusData.canFly;

	sendConfigData(DEBUG_DATA_BUFFER, 7, CMD_FC_DATA);

}

void debugFCStates() {
	DEBUG_DATA_BUFFER[0] = fcStatusData.isTxOn * 100;
	DEBUG_DATA_BUFFER[1] = fcStatusData.canStart * 10000;
	DEBUG_DATA_BUFFER[2] = fcStatusData.canArm * 10;
	DEBUG_DATA_BUFFER[3] = fcStatusData.canStabilize * 10;
	DEBUG_DATA_BUFFER[4] = fcStatusData.isStabilized * 10;
	DEBUG_DATA_BUFFER[5] = fcStatusData.canFly * 10;
	DEBUG_DATA_BUFFER[6] = fcStatusData.hasCrashed * 10;
	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void debugStablilization() {
	DEBUG_DATA_BUFFER[0] = fcStatusData.headingRef * 10;
	DEBUG_DATA_BUFFER[1] = sensorAttitudeData.heading * 10;
	DEBUG_DATA_BUFFER[2] = sensorAttitudeData.pitch * 10;
	DEBUG_DATA_BUFFER[3] = sensorAttitudeData.roll * 10;
	DEBUG_DATA_BUFFER[4] = (sensorAltitudeData.altitudeSLFiltered - fcStatusData.altitudeSLRef) * 10;
	DEBUG_DATA_BUFFER[5] = fcStatusData.altitudeSLRef * 10;
	DEBUG_DATA_BUFFER[6] = sensorAltitudeData.altitudeSLFiltered * 10;
	DEBUG_DATA_BUFFER[7] = getRCValue(RC_LAND_CHANNEL_INDEX);

	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

extern BIQUADFILTER noiseFilterFftNtfGyroX[SENSOR_FFT_GYRO_FREQUENCY_N];
extern BIQUADFILTER noiseFilterFftNtfGyroY[SENSOR_FFT_GYRO_FREQUENCY_N];
extern BIQUADFILTER noiseFilterFftNtfGyroZ[SENSOR_FFT_GYRO_FREQUENCY_N];

void debugDynamicNotch() {
/*
	DEBUG_DATA_BUFFER[0] = fftContextGyroX.peakNoise * 10;
	DEBUG_DATA_BUFFER[1] = fftContextGyroX.noiseFloor * 10;

	DEBUG_DATA_BUFFER[2] = fftContextGyroY.peakNoise * 10;
	DEBUG_DATA_BUFFER[3] = fftContextGyroY.noiseFloor * 10;

	DEBUG_DATA_BUFFER[4] = fftContextGyroZ.peakNoise * 10;
	DEBUG_DATA_BUFFER[5] = fftContextGyroZ.noiseFloor * 10;
*/
	DEBUG_DATA_BUFFER[6] = noiseFilterFftNtfGyroX[0].center_freq;
	DEBUG_DATA_BUFFER[7] = noiseFilterFftNtfGyroY[0].center_freq;
	//DEBUG_DATA_BUFFER[5] = noiseFilterFftNtfGyroZ[0].center_freq;
	/*
	 DEBUG_DATA_BUFFER[3] = noiseFilterFftNtfGyroX[1].center_freq;
	 DEBUG_DATA_BUFFER[4] = noiseFilterFftNtfGyroY[1].center_freq;
	 DEBUG_DATA_BUFFER[5] = noiseFilterFftNtfGyroZ[1].center_freq;

	 DEBUG_DATA_BUFFER[6] = noiseFilterFftNtfGyroX[2].center_freq;
	 DEBUG_DATA_BUFFER[7] = noiseFilterFftNtfGyroY[2].center_freq;
	 */
	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void debugFiltering() {
	DEBUG_DATA_BUFFER[0] = sensorAttitudeData.ayG * 100;
	DEBUG_DATA_BUFFER[1] = sensorAttitudeData.ayGFiltered * 100;

	DEBUG_DATA_BUFFER[3] = sensorAltitudeData.verticalVelocity * 100;
	DEBUG_DATA_BUFFER[4] = sensorAttitudeData.gxDS * 10;
	DEBUG_DATA_BUFFER[5] = sensorAttitudeData.pitchRate * 10;
	DEBUG_DATA_BUFFER[6] = noiseFilterFftNtfGyroX[0].center_freq;
	DEBUG_DATA_BUFFER[7] = noiseFilterFftNtfGyroY[0].center_freq;
	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void troubleshoot() {

	DEBUG_DATA_BUFFER[0] = sensorAttitudeData.gxDS * 10;
	DEBUG_DATA_BUFFER[1] = sensorAttitudeData.pitchRate * 10;

	DEBUG_DATA_BUFFER[2] = sensorAttitudeData.gyDS * 10;
	DEBUG_DATA_BUFFER[3] = sensorAttitudeData.rollRate * 10;

	DEBUG_DATA_BUFFER[4] = sensorAttitudeData.gzDS * 10;
	DEBUG_DATA_BUFFER[5] = sensorAttitudeData.yawRate * 10;

	DEBUG_DATA_BUFFER[6] = noiseFilterFftNtfGyroX[0].enabled ? noiseFilterFftNtfGyroX[0].center_freq : 0;
	DEBUG_DATA_BUFFER[7] = noiseFilterFftNtfGyroX[0].enabled ? noiseFilterFftNtfGyroY[0].center_freq : 0;

	sendConfigData(DEBUG_DATA_BUFFER, 8, CMD_FC_DATA);
}

void debugTask() {
	if (!fcStatusData.isDebugEnabled) {
		return;
	}
	float dt = getDeltaTime(DEBUG_TIMER_CHANNEL);
	//debugPWM();
	//debugHeading(dt);
	//debugImu(dt);
	//debugTime(dt);
	//debugAltitude();
	debugAttitude();
	//troubleshoot();
	//debugFiltering();
	//debugDynamicNotch();
	//debugFFT();
	//debugRC();
	//debugFCStates();
	//debugStablilization();
}

#else
uint8_t initDebugManager(void) {
	return 1;
}

#endif

