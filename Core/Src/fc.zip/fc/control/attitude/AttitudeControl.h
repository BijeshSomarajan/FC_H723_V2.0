#ifndef MODULES_ATTITUDE_CONTROL_H_
#define MODULES_ATTITUDE_CONTROL_H_

#include <sys/_stdint.h>

#define ATT_CONTROL_D_RATE_LPF_FREQ 200.0f

uint8_t initAttitudeControl();
void resetAttitudeControl(uint8_t hard);
void controlAttitude(float dt, float expectedPitch, float expectedRoll, float expectedYaw);

#endif
