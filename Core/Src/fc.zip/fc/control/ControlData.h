#ifndef _CONTROL_H_
#define _CONTROL_H_


typedef struct _CONTROL_DATA CONTROL_DATA;
struct _CONTROL_DATA {
	float throttleControl;
	float pitchControl;
	float rollControl;
	float yawControl;
	float altitudeControl;
	float positionPitchControl;
	float positionRollControl;
	float attitudeControlDt;
	float altitudeControlDt;
};

extern CONTROL_DATA controlData;

#endif
