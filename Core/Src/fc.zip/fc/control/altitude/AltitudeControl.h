#ifndef _ALTITUDECONTROL_H_
#define _ALTITUDECONTROL_H_

#include <stdio.h>
#include <inttypes.h>

uint8_t initAltitudeControl();
void resetAltitudeControl(uint8_t hard);
void resetAltitudeControlMaster(void);
void resetAltitudeControlRate(void);

void resetAltitudeRateControl(void);
void resetAltitudeMasterControl(void);
void controlAltitude(float dt, float expectedAltitude);


#define ALT_CONTROL_RATE_PID_D_LPF_FREQ 100.0f
#define ALT_CONTROL_PID_I_LIMIT_RATIO 0.75f
#define ALT_CONTROL_RATE_PID_D_LIMIT_RATIO 0.75f

#endif
