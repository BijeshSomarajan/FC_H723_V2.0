#include "IMU.h"

#if IMU_FILTER_SELECTED == IMU_FILTER_MANHONY_BF

#include "../util/MathUtil.h"
#include <math.h>

#define MAHONY_BF_FILTER_BF_SPIN_RATE_LIMIT 20
#define MAHONY_BF_FILTER_BF_USE_TRIG_APPROX 1 

#define MAHONY_BF_FILTER_BF_USE_INV_SQRT_APPROX 1
#define MAHONY_BF_FILTER_BF_USE_SQRT_APPROX 1 

// Lower values means more inclined to Gyroscope and less influence of accelerometer
#define MAHONY_BF_FILTER_KP  1.0f * .25f //0.25f   
#define MAHONY_BF_FILTER_KI  1.0f * 0.0f  
#define MAHONY_BF_FILTER_STABILIZE_KP  MAHONY_BF_FILTER_KP * 100.0f //1.75
#define MAHONY_BF_FILTER_STABILIZE_KI  MAHONY_BF_FILTER_KI * 100.0f
#define MAHONY_BF_FILTER_STAB_COUNT 5000

typedef struct {
	float ww, wx, wy, wz, xx, xy, xz, yy, yz, zz;
} MahonyFilter_BF_QuaternionProducts;

void imuFilterUpdate(float dt);
void imuFilterSetMode(uint8_t stablize);
uint8_t imuFilterInit(uint8_t stabilize);
void imuFilterReset(void);
uint16_t imuFilterGetStabilizationCount(void);
void imuFilterUpdateAngles(void);
void imuFilterUpdateHeading(float magIncl, float error);

#endif
