#ifndef IMU_IMU_H_
#define IMU_IMU_H_

#include <stdint.h>
#include <math.h>

#include "../memory/Memory.h"
#include "../util/MathUtil.h"

#define MAG_INCLINATION -1.1f 
#define MAG_ANGLE_CORRECTION -10.0f 

#define IMU_FILTER_MANHONY_BF 1
#define IMU_FILTER_MADGWICK 2

#define IMU_FILTER_SELECTED IMU_FILTER_MANHONY_BF   

/**
 * Structure representing IMU data
 */
typedef struct _IMU_DATA IMU_DATA;
struct _IMU_DATA {
	//Quaternions w, x ,y ,z
	float q0, q1, q2, q3; //z
	//Rotation matrix
	float rMatrix[3][3];
	//Euler angles
	float pitch, roll, yaw;
	//Azimuth NED heading
	float heading;
	//Motion rates
	float pitchRate, rollRate, yawRate ;
	//Linear accelerations
	float linAxGRaw, linAyGRaw, linAzGRaw;
	float linAxG, linAyG, linAzG;
	float linBodyVx, linBodyVy, linBodyVz;

	float arhsDt; 
};

extern IMU_DATA imuData;

uint16_t getImuStabilizationCount(void);
uint8_t imuInit(float magIncl);
void imuSetMode(uint8_t stabilize);
void imuReset(uint8_t hard);
void imuAHRSUpdate(float dt);
void imuUpdateRate(void);
void imuUpdateLinearVelocity(float dt);

//Increasing this will give waveform
#define IMU_LIN_ACC_LPF_ENABLED 1
#define IMU_LIN_ACC_LPF_CUTOFF  0.05f

#define IMU_LIN_VEL_LPF_ENABLED 1
#define IMU_LIN_VEL_LPF_CUTOFF  0.05f 
/*
 A smaller alpha makes the filter "leak" more slowly, leading to a smoother output. 
 A larger alpha causes the output to track the input more closely.
*/
#define IMU_LIN_VEL_LEAK_FACTOR 0.1f

#define IMU_LIN_VEL_MAX 1.0f
#define IMU_LIN_ACC_MAX 0.98f * 2.0f

#define IMU_LIN_VEL_DB_ENABLED 0
#define IMU_LIN_VEL_DB 0.005f

#endif
