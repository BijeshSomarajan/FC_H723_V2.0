#include "../sensors/attitude/AttitudeSensor.h"
#include "../util/MathUtil.h"
#include "IMU.h"

#include "../dsp/LeakyIntegrationFlilter.h"
#include "../dsp/LowPassFilter.h"
#include "MadgwickFilter.h"
#include "MahonyFilter_BF.h"

IMU_DATA imuData;
extern SENSOR_ATTITUDE_DATA sensorAttitudeData;

LOWPASSFILTER imuAxBodyLPF, imuAyBodyLPF, imuAzBodyLPF;
LEAKYINTEGRATIONFILTER linVxLeakyFilter, linVyLeakyFilter, linVzLeakyFilter;
LOWPASSFILTER imuVxBodyLPF, imuVyBodyLPF, imuVzBodyLPF;

float imuMagInclination = 0;

uint16_t getImuStabilizationCount() {
	return imuFilterGetStabilizationCount();
}

/*****************************************************************************************************************/
// Initializes imuData.
/*****************************************************************************************************************/
uint8_t imuInit(float pMagInclination) {
	imuReset(1);
	imuMagInclination = pMagInclination;

	lowPassFilterInit(&imuAxBodyLPF, IMU_LIN_ACC_LPF_CUTOFF);
	lowPassFilterInit(&imuAyBodyLPF, IMU_LIN_ACC_LPF_CUTOFF);
	lowPassFilterInit(&imuAzBodyLPF, IMU_LIN_ACC_LPF_CUTOFF);

	lowPassFilterInit(&imuVxBodyLPF, IMU_LIN_VEL_LPF_CUTOFF);
	lowPassFilterInit(&imuVyBodyLPF, IMU_LIN_VEL_LPF_CUTOFF);
	lowPassFilterInit(&imuVzBodyLPF, IMU_LIN_VEL_LPF_CUTOFF);

	leakyIntegrationFilterInit(&linVxLeakyFilter, IMU_LIN_VEL_LEAK_FACTOR);
	leakyIntegrationFilterInit(&linVyLeakyFilter, IMU_LIN_VEL_LEAK_FACTOR);
	leakyIntegrationFilterInit(&linVzLeakyFilter, IMU_LIN_VEL_LEAK_FACTOR);

	imuFilterInit(1);

	return 1;
}

void imuSetMode(uint8_t stabilize) {
	imuFilterSetMode(stabilize);
}

__ATTR_ITCM_TEXT
void imuUpdateRate() {
	// Flush the rates, Note: X and Y gyros are interchanged
	imuData.pitchRate = sensorAttitudeData.gxDSFiltered;
	imuData.rollRate = sensorAttitudeData.gyDSFiltered;
	imuData.yawRate = sensorAttitudeData.gzDSFiltered;
}

__ATTR_ITCM_TEXT
void imuCalculateLinearAcc(float dt) {
	// 1. Initialize static bias terms to 0.0f
	// This prevents "ghost" offsets if the LPF is toggled off during runtime.
	static float axGBodyBias = 0.0f, ayGBodyBias = 0.0f, azGBodyBias = 0.0f;
	static float vxGBodyBias = 0.0f, vyGBodyBias = 0.0f, vzGBodyBias = 0.0f;

	// 2. Earth Frame Linear Acceleration (Standard NED/ENU)
	// We rotate raw accel to Earth frame and subtract 1G from the Vertical (Z) axis.
	sensorAttitudeData.axGEarth = (imuData.rMatrix[0][0] * sensorAttitudeData.axG + imuData.rMatrix[0][1] * sensorAttitudeData.ayG + imuData.rMatrix[0][2] * sensorAttitudeData.azG);
	sensorAttitudeData.ayGEarth = (imuData.rMatrix[1][0] * sensorAttitudeData.axG + imuData.rMatrix[1][1] * sensorAttitudeData.ayG + imuData.rMatrix[1][2] * sensorAttitudeData.azG);
	sensorAttitudeData.azGEarth = (imuData.rMatrix[2][0] * sensorAttitudeData.axG + imuData.rMatrix[2][1] * sensorAttitudeData.ayG + imuData.rMatrix[2][2] * sensorAttitudeData.azG) - 1.0f;

	// 3. Body Frame Linear Acceleration
	// We use the 3rd column of the rMatrix to find the gravity vector as seen by the sensor.
	// rMatrix[row][column]: [0][2]=X-gravity, [1][2]=Y-gravity, [2][2]=Z-gravity.

	sensorAttitudeData.axGBody = sensorAttitudeData.axGFiltered - imuData.rMatrix[0][2];
	sensorAttitudeData.ayGBody = sensorAttitudeData.ayGFiltered - imuData.rMatrix[1][2];
	sensorAttitudeData.azGBody = sensorAttitudeData.azGFiltered - imuData.rMatrix[2][2];

	// 4. Estimate and Remove Acceleration Bias (Vibration/Sensor Offset)
#if IMU_LIN_ACC_LPF_ENABLED == 1
	axGBodyBias = lowPassFilterUpdate(&imuAxBodyLPF, sensorAttitudeData.axGBody, dt);
	ayGBodyBias = lowPassFilterUpdate(&imuAyBodyLPF, sensorAttitudeData.ayGBody, dt);
	azGBodyBias = lowPassFilterUpdate(&imuAzBodyLPF, sensorAttitudeData.azGBody, dt);
#endif

	sensorAttitudeData.axGBody = constrainToRangeF(sensorAttitudeData.axGBody - axGBodyBias, -IMU_LIN_ACC_MAX, IMU_LIN_ACC_MAX);
	sensorAttitudeData.ayGBody = constrainToRangeF(sensorAttitudeData.ayGBody - ayGBodyBias, -IMU_LIN_ACC_MAX, IMU_LIN_ACC_MAX);
	sensorAttitudeData.azGBody = constrainToRangeF(sensorAttitudeData.azGBody - azGBodyBias, -IMU_LIN_ACC_MAX, IMU_LIN_ACC_MAX);

	// 5. Velocity Integration (Leaky Integrator to prevent drift)
	// Convert G's to m/s^2 by multiplying by 9.81f
	imuData.linBodyVx = leakyIntegrationFilterUpdate(&linVxLeakyFilter, sensorAttitudeData.axGBody * 9.81f, dt);
	imuData.linBodyVy = leakyIntegrationFilterUpdate(&linVyLeakyFilter, sensorAttitudeData.ayGBody * 9.81f, dt);
	imuData.linBodyVz = leakyIntegrationFilterUpdate(&linVzLeakyFilter, sensorAttitudeData.azGBody * 9.81f, dt);

	// 6. Velocity Bias Removal and Deadband
#if IMU_LIN_VEL_LPF_ENABLED == 1
	vxGBodyBias = lowPassFilterUpdate(&imuVxBodyLPF, imuData.linBodyVx, dt);
	vyGBodyBias = lowPassFilterUpdate(&imuVyBodyLPF, imuData.linBodyVy, dt);
	vzGBodyBias = lowPassFilterUpdate(&imuVzBodyLPF, imuData.linBodyVz, dt);
#endif

	imuData.linBodyVx = applyDeadBandFloat(0, imuData.linBodyVx - vxGBodyBias, IMU_LIN_VEL_DB);
	imuData.linBodyVy = applyDeadBandFloat(0, imuData.linBodyVy - vyGBodyBias, IMU_LIN_VEL_DB);
	imuData.linBodyVz = applyDeadBandFloat(0, imuData.linBodyVz - vzGBodyBias, IMU_LIN_VEL_DB);

	// 7. Optional: Velocity Constraints
#if IMU_LIN_VEL_DB_ENABLED == 1
    imuData.linBodyVx = constrainToRangeF(imuData.linBodyVx, -IMU_LIN_VEL_MAX, IMU_LIN_VEL_MAX);
    imuData.linBodyVy = constrainToRangeF(imuData.linBodyVy, -IMU_LIN_VEL_MAX, IMU_LIN_VEL_MAX);
    imuData.linBodyVz = constrainToRangeF(imuData.linBodyVz, -IMU_LIN_VEL_MAX, IMU_LIN_VEL_MAX);
#endif
}

/*
 void imuCalculateLinearAccOls(float dt) {
 static float axGBodyBias, ayGBodyBias, azGBodyBias, vxGBodyBias, vyGBodyBias, vzGBodyBias;
 sensorAttitudeData.axGEarth = (imuData.rMatrix[0][0] * sensorAttitudeData.axG + imuData.rMatrix[0][1] * sensorAttitudeData.ayG + imuData.rMatrix[0][2] * (sensorAttitudeData.azG));
 sensorAttitudeData.ayGEarth = (imuData.rMatrix[1][0] * sensorAttitudeData.axG + imuData.rMatrix[1][1] * sensorAttitudeData.ayG + imuData.rMatrix[1][2] * (sensorAttitudeData.azG));
 sensorAttitudeData.azGEarth = (imuData.rMatrix[2][0] * sensorAttitudeData.axG + imuData.rMatrix[2][1] * sensorAttitudeData.ayG + imuData.rMatrix[2][2] * (sensorAttitudeData.azG)) - 1.0f;

 sensorAttitudeData.axGBody = sensorAttitudeData.axGFiltered - (2 * (imuData.q1 * imuData.q3 - imuData.q0 * imuData.q2));
 sensorAttitudeData.ayGBody = sensorAttitudeData.ayGFiltered - (2 * (imuData.q0 * imuData.q1 + imuData.q2 * imuData.q3));
 sensorAttitudeData.azGBody = sensorAttitudeData.azGEarth;

 #if IMU_LIN_ACC_LPF_ENABLED == 1
 axGBodyBias = lowPassFilterUpdate(&imuAxBodyLPF, sensorAttitudeData.axGBody, dt);
 ayGBodyBias = lowPassFilterUpdate(&imuAyBodyLPF, sensorAttitudeData.ayGBody, dt);
 azGBodyBias = lowPassFilterUpdate(&imuAzBodyLPF, sensorAttitudeData.azGBody, dt);
 #endif

 sensorAttitudeData.axGBody -= axGBodyBias;
 sensorAttitudeData.ayGBody -= ayGBodyBias;
 sensorAttitudeData.azGBody -= azGBodyBias;

 sensorAttitudeData.axGBody = constrainToRangeF(sensorAttitudeData.axGBody, -IMU_LIN_ACC_MAX, IMU_LIN_ACC_MAX);
 sensorAttitudeData.ayGBody = constrainToRangeF(sensorAttitudeData.ayGBody, -IMU_LIN_ACC_MAX, IMU_LIN_ACC_MAX);
 sensorAttitudeData.azGBody = constrainToRangeF(sensorAttitudeData.azGBody, -IMU_LIN_ACC_MAX, IMU_LIN_ACC_MAX);

 imuData.linBodyVx = leakyIntegrationFilterUpdate(&linVxLeakyFilter, sensorAttitudeData.axGBody * 9.81f, dt);
 imuData.linBodyVy = leakyIntegrationFilterUpdate(&linVyLeakyFilter, sensorAttitudeData.ayGBody * 9.81f, dt);
 imuData.linBodyVz = leakyIntegrationFilterUpdate(&linVzLeakyFilter, sensorAttitudeData.azGBody * 9.81f, dt);

 #if IMU_LIN_VEL_LPF_ENABLED == 1
 vxGBodyBias = lowPassFilterUpdate(&imuVxBodyLPF, imuData.linBodyVx, dt);
 vyGBodyBias = lowPassFilterUpdate(&imuVyBodyLPF, imuData.linBodyVy, dt);
 vzGBodyBias = lowPassFilterUpdate(&imuVzBodyLPF, imuData.linBodyVz, dt);
 #endif

 imuData.linBodyVx -= vxGBodyBias;
 imuData.linBodyVy -= vyGBodyBias;
 imuData.linBodyVz -= vzGBodyBias;

 imuData.linBodyVx = applyDeadBandFloat(0, imuData.linBodyVx, IMU_LIN_VEL_DB);
 imuData.linBodyVy = applyDeadBandFloat(0, imuData.linBodyVy, IMU_LIN_VEL_DB);
 imuData.linBodyVz = applyDeadBandFloat(0, imuData.linBodyVz, IMU_LIN_VEL_DB);

 #if IMU_LIN_VEL_DB_ENABLED == 1
 imuData.linBodyVx = constrainToRangeF(imuData.linBodyVx, -IMU_LIN_VEL_MAX, IMU_LIN_VEL_MAX);
 imuData.linBodyVy = constrainToRangeF(imuData.linBodyVy, -IMU_LIN_VEL_MAX, IMU_LIN_VEL_MAX);
 imuData.linBodyVz = constrainToRangeF(imuData.linBodyVz, -IMU_LIN_VEL_MAX, IMU_LIN_VEL_MAX);
 #endif

 }
 */

/*************************************************************************/
// Does imuData fusion , returns 1 if done
/*************************************************************************/
__ATTR_ITCM_TEXT
void imuAHRSUpdate(float dt) {
	imuFilterUpdate(dt);
	imuFilterUpdateAngles();
	imuFilterUpdateHeading(imuMagInclination, MAG_ANGLE_CORRECTION);
	imuCalculateLinearAcc(dt);
	imuData.arhsDt = dt;
}

/****************************************************************************************************************/
// Resets Madgwick filter.
/****************************************************************************************************************/
void imuReset(uint8_t hard) {
	if (hard) {
		// Reset the quaternion
		imuData.q0 = 1.0f;
		imuData.q1 = 0.0f;
		imuData.q2 = 0.0f;
		imuData.q3 = 0.0f;

		// Reset the rotation matrix
		imuData.rMatrix[0][0] = 0;
		imuData.rMatrix[0][1] = 0;
		imuData.rMatrix[0][2] = 0;

		imuData.rMatrix[1][0] = 0;
		imuData.rMatrix[1][1] = 0;
		imuData.rMatrix[1][2] = 0;

		imuData.rMatrix[2][0] = 0;
		imuData.rMatrix[2][1] = 0;
		imuData.rMatrix[2][2] = 0;

		// Reset the euler angles
		imuData.pitch = 0;
		imuData.roll = 0;
		imuData.yaw = 0;
		imuData.heading = 0;

		// Reset the rates
		imuData.pitchRate = 0;
		imuData.rollRate = 0;
		imuData.yawRate = 0;

		// Reset the specific filter
		imuFilterReset();
	}

	imuData.linBodyVx = 0;
	imuData.linBodyVy = 0;
	imuData.linBodyVz = 0;

	lowPassFilterReset(&imuVxBodyLPF);
	lowPassFilterReset(&imuVyBodyLPF);
	lowPassFilterReset(&imuVzBodyLPF);

	lowPassFilterReset(&imuAxBodyLPF);
	lowPassFilterReset(&imuAyBodyLPF);
	lowPassFilterReset(&imuAzBodyLPF);

	leakyIntegrationFilterReset(&linVxLeakyFilter, 0);
	leakyIntegrationFilterReset(&linVyLeakyFilter, 0);
	leakyIntegrationFilterReset(&linVzLeakyFilter, 0);
}
