#include "IMU.h"

#if IMU_FILTER_SELECTED == IMU_FILTER_MANHONY_BF
#include "../sensors/attitude/AttitudeSensor.h"
#include "MahonyFilter_BF.h"

float __ATTR_DTCM_BSS mahonyFilter_BF_KP = MAHONY_BF_FILTER_KP;
float __ATTR_DTCM_BSS mahonyFilter_BF_KI = MAHONY_BF_FILTER_KI;
float __ATTR_DTCM_BSS mahonyFilter_MaxSpinRateRad = 0;

// Integral error terms
float __ATTR_DTCM_BSS mahonyFilter_BF_IBx = 0.0f;
float __ATTR_DTCM_BSS mahonyFilter_BF_IBy = 0.0f;
float __ATTR_DTCM_BSS mahonyFilter_BF_IBz = 0.0f;

uint16_t imuFilterGetStabilizationCount() {
	return MAHONY_BF_FILTER_STAB_COUNT;
}

__ATTR_ITCM_TEXT
void imuFilterUpdateAngles(void) {
#if MAHONY_BF_FILTER_BF_USE_TRIG_APPROX == 1
	imuData.roll = convertRadToDeg(atan2Approx(imuData.rMatrix[2][1], imuData.rMatrix[2][2]));
	imuData.pitch = convertRadToDeg(HalfPI - acosApprox(-imuData.rMatrix[2][0]));
	imuData.yaw = convertRadToDeg(-atan2Approx(imuData.rMatrix[1][0], imuData.rMatrix[0][0]));
#else
	imuData.roll = convertRadToDeg(atan2f(imuData.rMatrix[2][1], imuData.rMatrix[2][2]));
	imuData.pitch = convertRadToDeg(HalfPI - acosf(-imuData.rMatrix[2][0]));
	imuData.yaw = convertRadToDeg(-atan2f(imuData.rMatrix[1][0], imuData.rMatrix[0][0]));
#endif
}

/**
 * Converts yaw to heading
 */
__ATTR_ITCM_TEXT
void imuFilterUpdateHeading(float magIncl, float error) {
	imuData.heading = -imuData.yaw;
	if (imuData.heading < 0.0f) {
		imuData.heading += 360.0f;
	} else if (imuData.heading > 360.0f) {
		imuData.heading -= 360.0f;
	}
	imuData.heading += (magIncl + error);
	if (imuData.heading > 360) {
		imuData.heading -= 360;
	} else if (imuData.heading < 0) {
		imuData.heading += 360;
	}
}

__ATTR_ITCM_TEXT
void mahonyFilterUpdateRotationMatrix(void) {
	float q0, q1, q2, q3, q1_sq, q2_sq, q3_sq, q0q1, q0q2, q0q3, q1q2, q1q3, q2q3;
	// Access quaternion components directly using the dot operator
	q0 = imuData.q0;
	q1 = imuData.q1;
	q2 = imuData.q2;
	q3 = imuData.q3;

	// Pre-calculate squares and products for efficiency
	// float q0_sq = q0 * q0;
	q1_sq = q1 * q1;
	q2_sq = q2 * q2;
	q3_sq = q3 * q3;

	q0q1 = q0 * q1;
	q0q2 = q0 * q2;
	q0q3 = q0 * q3;
	q1q2 = q1 * q2;
	q1q3 = q1 * q3;
	q2q3 = q2 * q3;

	// Build and store the rotation matrix directly into the local copy
	// Row 1
	imuData.rMatrix[0][0] = 1.0f - 2.0f * (q2_sq + q3_sq);
	imuData.rMatrix[0][1] = 2.0f * (q1q2 - q0q3);
	imuData.rMatrix[0][2] = 2.0f * (q1q3 + q0q2);

	// Row 2
	imuData.rMatrix[1][0] = 2.0f * (q1q2 + q0q3);
	imuData.rMatrix[1][1] = 1.0f - 2.0f * (q1_sq + q3_sq);
	imuData.rMatrix[1][2] = 2.0f * (q2q3 - q0q1);

	// Row 3
	imuData.rMatrix[2][0] = 2.0f * (q1q3 - q0q2);
	imuData.rMatrix[2][1] = 2.0f * (q2q3 + q0q1);
	imuData.rMatrix[2][2] = 1.0f - 2.0f * (q1_sq + q2_sq);
}

__ATTR_ITCM_TEXT
void imuFilterUpdate(float dt) {
	float gx, gy, gz, ax, ay, az, mx, my, mz, halfDt, ex, ey, ez, spin_rate, hx, hy, bx, ez_ef, recipNorm;
	// Copy the variables locally
	gx = convertDegToRad(sensorAttitudeData.gxDSFiltered);
	gy = convertDegToRad(sensorAttitudeData.gyDSFiltered);
	gz = convertDegToRad(sensorAttitudeData.gzDSFiltered);
	ax = sensorAttitudeData.axGFiltered;
	ay = sensorAttitudeData.ayGFiltered;
	az = sensorAttitudeData.azGFiltered;
	mx = sensorAttitudeData.mxFiltered;
	my = sensorAttitudeData.myFiltered;
	mz = sensorAttitudeData.mzFiltered;
	halfDt = 0.5f * dt;
	// Use raw heading error (from GPS or whatever else)
	ex = 0;
	ey = 0;
	ez = 0;

	if (!((mx == 0.0f) && (my == 0.0f) && (mz == 0.0f))) {
		// Use measured magnetic field vector
		recipNorm = power2f(mx) + power2f(my) + power2f(mz);
		// Normalize magnetometer measurement

#if MAHONY_BF_FILTER_BF_USE_INV_SQRT_APPROX == 1
		recipNorm = fastInvSqrtf(recipNorm);
#else
		recipNorm = invSqrtf(recipNorm);
#endif
		mx *= recipNorm;
		my *= recipNorm;
		mz *= recipNorm;
		// For magnetometer correction we make an assumption that magnetic field is perpendicular to gravity (ignore Z-component in EF).
		// This way magnetic field will only affect heading and wont mess roll/pitch angles
		// (hx; hy; 0) - measured mag field vector in EF (assuming Z-component is zero)
		// (bx; 0; 0) - reference mag field vector heading due North in EF (assuming Z-component is zero)
		hx = imuData.rMatrix[0][0] * mx + imuData.rMatrix[0][1] * my + imuData.rMatrix[0][2] * mz;
		hy = imuData.rMatrix[1][0] * mx + imuData.rMatrix[1][1] * my + imuData.rMatrix[1][2] * mz;

#if MAHONY_BF_FILTER_BF_USE_SQRT_APPROX == 1
		bx = fastSqrtf(hx * hx + hy * hy);
#else
		bx = sqrtf(hx * hx + hy * hy);
#endif

		// magnetometer error is cross product between estimated magnetic north and measured magnetic north (calculated in EF)
		ez_ef = -(hy * bx);
		// Rotate mag error vector back to BF and accumulate
		ex += (imuData.rMatrix[2][0] * ez_ef);
		ey += (imuData.rMatrix[2][1] * ez_ef);
		ez += (imuData.rMatrix[2][2] * ez_ef);
	}

	if (!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f))) {
		// Use measured acceleration vector
		recipNorm = power2f(ax) + power2f(ay) + power2f(az);

		// Normalize accelerometer measurement
#if MAHONY_BF_FILTER_BF_USE_INV_SQRT_APPROX == 1
		recipNorm = fastInvSqrtf(recipNorm);
#else
		recipAccNorm = invSqrtf(recipAccNorm);
#endif
		ax *= recipNorm;
		ay *= recipNorm;
		az *= recipNorm;
		// Error is sum of cross product between estimated direction and measured direction of gravity
		ex += ((ay * imuData.rMatrix[2][2]) - (az * imuData.rMatrix[2][1]));
		ey += ((az * imuData.rMatrix[2][0]) - (ax * imuData.rMatrix[2][2]));
		ez += ((ax * imuData.rMatrix[2][1]) - (ay * imuData.rMatrix[2][0]));
	}

	// Compute and apply integral feedback if enabled
	if (mahonyFilter_BF_KI > 0.0f) {
// Calculate general spin rate (rad/s)
#if MAHONY_BF_FILTER_BF_USE_SQRT_APPROX == 1
		spin_rate = fastSqrtf(power2f(gx) + power2f(gy) + power2f(gz));
#else
		spin_rate = sqrtf(power2f(gx) + power2f(gy) + power2f(gz));
#endif
		// Stop integrating if spinning beyond the certain limit
		if (spin_rate <= mahonyFilter_MaxSpinRateRad) {
			mahonyFilter_BF_IBx += (mahonyFilter_BF_KI * ex * dt); // integral error scaled by Ki
			mahonyFilter_BF_IBy += (mahonyFilter_BF_KI * ey * dt);
			mahonyFilter_BF_IBz += (mahonyFilter_BF_KI * ez * dt);
		}
	} else {
		mahonyFilter_BF_IBx = 0.0f; // prevent integral windup
		mahonyFilter_BF_IBy = 0.0f;
		mahonyFilter_BF_IBz = 0.0f;
	}

	// Apply proportional and integral feedback
	gx += ((mahonyFilter_BF_KP * ex) + mahonyFilter_BF_IBx);
	gy += ((mahonyFilter_BF_KP * ey) + mahonyFilter_BF_IBy);
	gz += ((mahonyFilter_BF_KP * ez) + mahonyFilter_BF_IBz);

	// Integrate rate of change of quaternion
	gx *= halfDt;
	gy *= halfDt;
	gz *= halfDt;

	// Compute the new quaternion
	imuData.q0 += (-(imuData.q1 * gx) - (imuData.q2 * gy) - (imuData.q3 * gz));
	imuData.q1 += ((imuData.q0 * gx) + (imuData.q2 * gz) - (imuData.q3 * gy));
	imuData.q2 += ((imuData.q0 * gy) - (imuData.q1 * gz) + (imuData.q3 * gx));
	imuData.q3 += ((imuData.q0 * gz) + (imuData.q1 * gy) - (imuData.q2 * gx));

	// Normalize quaternion 
#if MAHONY_BF_FILTER_BF_USE_INV_SQRT_APPROX == 1
	recipNorm = fastInvSqrtf(power2f(imuData.q0) + power2f(imuData.q1) + power2f(imuData.q2) + power2f(imuData.q3));
#else
	recipNorm = invSqrtf(power2f(imuData.q0) + power2f(imuData.q1) + power2f(imuData.q2) + power2f(imuData.q3));
#endif

	imuData.q0 *= recipNorm;
	imuData.q1 *= recipNorm;
	imuData.q2 *= recipNorm;
	imuData.q3 *= recipNorm;

	// Compute rotation matrix from quaternion
	mahonyFilterUpdateRotationMatrix();
}

void imuFilterSetMode(uint8_t stablize) {
	if (stablize) {
		mahonyFilter_BF_KP = MAHONY_BF_FILTER_STABILIZE_KP;
		mahonyFilter_BF_KI = MAHONY_BF_FILTER_STABILIZE_KI;
	} else {
		mahonyFilter_BF_KP = MAHONY_BF_FILTER_KP;
		mahonyFilter_BF_KI = MAHONY_BF_FILTER_KI;
	}
}

uint8_t imuFilterInit(uint8_t stabilize) {
	imuFilterSetMode(stabilize);
	imuFilterReset();
	mahonyFilterUpdateRotationMatrix();
	mahonyFilter_MaxSpinRateRad = convertDegToRad(MAHONY_BF_FILTER_BF_SPIN_RATE_LIMIT);
	return 1;
}

void mahonyFilterResetRotationMatrix() {
	// Reset all elements to 0
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			imuData.rMatrix[i][j] = 0.0f;
		}
	}
	// Set the diagonal elements to 1
	imuData.rMatrix[0][0] = 1.0f;
	imuData.rMatrix[1][1] = 1.0f;
	imuData.rMatrix[2][2] = 1.0f;
}

void imuFilterReset() {
	imuData.q0 = 1.0f;
	imuData.q1 = 0.0f;
	imuData.q2 = 0.0f;
	imuData.q3 = 0.0f;
	mahonyFilterResetRotationMatrix();
}

#endif
