#ifndef FC_FCDSP_INCLUDE_FFT_H_
#define FC_FCDSP_INCLUDE_FFT_H_

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

#include "LowPassFilter.h"

#define FFT_N             128  // Must be power of 2
#define FFT_HALF_N        (FFT_N/2)
#define FFT_TOP_FREQ_N     2
#define FFT_HOP_SIZE      (FFT_N / 2) // M: 50% Overlap

// --- Feature Toggles ---
#define FFT_ENABLE_WINDOWING    1
#define FFT_ENABLE_BUDGET_FOR_WINDOWING  0

#define FFT_ENABLE_SAMPLE_LPF   1
#define FFT_ENABLE_SAMPLE_LPF_CUTOFF_FREQUENCY   600.0f

#define FFT_USE_FAST_SQRT  1

#define FFT_MODE_HARMONICS   1
#define FFT_MODE_PEAKS   2
#define FFT_MODE FFT_MODE_HARMONICS

#define FFT_CALCULATE_HARMONIC_FREQUENCIES 1

/*
 #define FFT_NOISE_EMA_RISE_ALPHA   0.04f
 #define FFT_NOISE_EMA_FALL_ALPHA   0.10f
 #define FFT_NOISE_MIN_FLOOR        0.25f
 #define FFT_PEAK_REJECT_RATIO      0.28f
 #define FFT_NOISE_MULTIPLIER       2.0f
 #define FFT_MAX_FREQ_SLEW_HZ_PER_MS 2.0f
 #define FFT_NOISE_FLOOR_MIN_HZ      40.0f
 #define FFT_MAX_BIN_FRACTION_FOR_NOISE  0.8f
 */

/* --- Noise model - Medium Soft Mounting --- */
#define FFT_NOISE_EMA_RISE_ALPHA   0.10f
#define FFT_NOISE_EMA_FALL_ALPHA   0.04f
#define FFT_NOISE_MIN_FLOOR        0.28f
#define FFT_PEAK_REJECT_RATIO      2.2f
#define FFT_NOISE_MULTIPLIER       5.0f
#define FFT_MAX_FREQ_SLEW_HZ_PER_MS 0.25f
#define FFT_NOISE_FLOOR_MIN_HZ      50.0f
#define FFT_MAX_BIN_FRACTION_FOR_NOISE  0.6f

/* --- Noise model - Very Soft Mounting --- */
/*
 #define FFT_NOISE_EMA_RISE_ALPHA 0.10f
 #define FFT_NOISE_EMA_FALL_ALPHA 0.04f
 #define FFT_NOISE_MIN_FLOOR 0.20f
 #define FFT_PEAK_REJECT_RATIO 2.2f
 #define FFT_NOISE_MULTIPLIER 5.0f
 #define FFT_MAX_FREQ_SLEW_HZ_PER_MS 0.2f
 #define FFT_NOISE_FLOOR_MIN_HZ 50.0f
 #define FFT_MAX_BIN_FRACTION_FOR_NOISE 0.6f
 */

typedef struct {
	float real;
	float imag;
} FFTData;

typedef enum {
	FFT_PHASE_IDLE,    // Waiting for new samples
	FFT_PHASE_WINDOW,  // Apply window to the new buffer
	FFT_PHASE_BITREV,  // Incremental bit reversal
	FFT_PHASE_STAGES,  // Incremental butterfly calculation
	FFT_PHASE_DONE     // Magnitude/peak calculation
} FFTPhase;

typedef struct {
	FFTData fftData[FFT_N];
	float fftMagnitudes[FFT_HALF_N + 1];

	float topFreq[FFT_TOP_FREQ_N];
	float topMagn[FFT_TOP_FREQ_N];
	float fftSamplingFrequency;
	uint16_t fftSampleCount;

	FFTPhase phase;             // Current phase of processing
	uint8_t processing;         // 1 if currently performing a step, 0 otherwise

	int stage;                  // Current FFT stage (1 to log2(N))
	int start;                  // Current butterfly group start index
	int i;                      // Current butterfly index within the group
	int br_i;                   // Current index for bit reversal
	int br_reversed;            // Current bit-reversed index
	float windowBuffer[FFT_N];  // Temp buffer for overlap shift/storage
	float noiseFloor;
	float peakNoise;

	uint8_t hasProcessUpdate;

	LOWPASSFILTER sampleLPF;

} FFTContext;

void initFFT(float sampleFrequency);
void initFFTContext(FFTContext *ctx);

uint8_t updateFFT(FFTContext *ctx, float input, float dt);
uint8_t processFFT(FFTContext *ctx, uint16_t processingBudget);

#endif
