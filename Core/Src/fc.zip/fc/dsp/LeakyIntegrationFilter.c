#include "LeakyIntegrationFlilter.h"

void leakyIntegrationFilterInit(LEAKYINTEGRATIONFILTER *self, float alhpa) {
	// A smaller alpha makes the filter "leak" more slowly, leading to a smoother output.
	// A larger alpha causes the output to track the input more closely.
	self->alpha = alhpa;
}

float leakyIntegrationFilterUpdate(LEAKYINTEGRATIONFILTER *self, float input, float dt) {
	// Update the filtered value using leaky integration with time consideration
	float alpha_dt = self->alpha * dt;
	self->output = alpha_dt * input + (1 - alpha_dt) * self->output;
	return self->output;
}

void leakyIntegrationFilterReset(LEAKYINTEGRATIONFILTER *self, float value) {
	self->output = value;
}

