#include "AltitudeSensor.h"

#include "../../dsp/LowPassFilter.h"
#include "../../imu/IMU.h"
#include "../../logger/Logger.h"
#include "../../util/MathUtil.h"
#include "devices/AltitudeDevice.h"

SENSOR_ALTITUDE_DATA sensorAltitudeData;
extern DEVICE_ALTITUDE_DATA deviceAltitudeData;

LOWPASSFILTER sensorAltBaroLPF;
LOWPASSFILTER sensorAltVelocityLPF;

uint8_t initAltitudeSensors(void) {
	uint8_t status = 1;
	status = deviceBaroInit();
	if (status) {
		logString("[Altitude Sensor] Baro Sensor Init > Success\n");
		lowPassFilterInit(&sensorAltBaroLPF, SENSOR_ALT_BARO_LPF_FREQUENCY);
		lowPassFilterInit(&sensorAltVelocityLPF, SENSOR_ALT_VERTICAL_VELOCITY_LPF_FREQ);
	} else {
		logString("[Altitude Sensor] Baro Sensor Init > Failed\n");
	}
	return status;
}

__ATTR_ITCM_TEXT
void scaleSeaLevelAlt() {
	sensorAltitudeData.altitudeSLScaled = sensorAltitudeData.altitudeSL * SENSOR_ALT_BARO_ALTITUDE_GAIN;
}

__ATTR_ITCM_TEXT
void filterSeaLevelAlt(float dt) {
	sensorAltitudeData.altitudeSLFiltered = lowPassFilterUpdate(&sensorAltBaroLPF, sensorAltitudeData.altitudeSLScaled, dt);
}

__ATTR_ITCM_TEXT
void estimateSeaLevelAlt(float dt, float altitudeBias) {
	float predictedAltitude = sensorAltitudeData.altitudeSLEstimated + (sensorAltitudeData.verticalVelocity * dt * SENSOR_ALT_ESTIMATE_VEL_GAIN);
	float sensorAltitude = sensorAltitudeData.altitudeSLFiltered - altitudeBias;
	sensorAltitudeData.altitudeSLEstimated = SENSOR_ALT_ESTIMATE_ALPHA * predictedAltitude + SENSOR_ALT_ESTIMATE_ONE_MINUS_ALPHA * sensorAltitude;
}

__ATTR_ITCM_TEXT
void updateAltitudeVelocity(float dt) {
	float altitudeV = applyDeadBandFloat(0.0f, imuData.linBodyVz, SENSOR_ALT_VERTICAL_VELOCITY_DEADBAND);
	altitudeV = altitudeV * SENSOR_ALT_VERTICAL_VELOCITY_OUTPUT_GAIN;
	altitudeV = constrainToRangeF(altitudeV, -SENSOR_ALT_VERTICAL_VELOCITY_MAX, SENSOR_ALT_VERTICAL_VELOCITY_MAX);
	sensorAltitudeData.verticalVelocity = lowPassFilterUpdate(&sensorAltVelocityLPF, altitudeV, dt);
}

__ATTR_ITCM_TEXT
void processAltitude(float dt, float altitudeBias) {
	updateAltitudeVelocity(dt);
	estimateSeaLevelAlt(dt, altitudeBias);
	sensorAltitudeData.altProcessDt = dt;
}

__ATTR_ITCM_TEXT
void updateAltitude(float dt) {
	scaleSeaLevelAlt();
	filterSeaLevelAlt(dt);
	sensorAltitudeData.altDataUpdateDt = dt;
}

__ATTR_ITCM_TEXT
uint8_t loadAltitudeSensorsData() {
	if (deviceBaroLoadData()) {
		sensorAltitudeData.altitudeSL = deviceAltitudeData.altitude;
		return 1;
	}
	return 0;
}

uint8_t readAltitudeSensors() {
	return deviceBaroRead();
}

void resetAltitudeSensors(uint8_t hard) {
	lowPassFilterResetToValue(&sensorAltBaroLPF, 0);
	lowPassFilterResetToValue(&sensorAltVelocityLPF, 0);
	sensorAltitudeData.altitudeSLEstimated = 0;
	sensorAltitudeData.altitudeSLFiltered = 0;
	sensorAltitudeData.altitudeSLScaled = 0;
	sensorAltitudeData.altitudeSLScaled = 0;
	if (hard) {
		deviceBaroReset();
	}
}

