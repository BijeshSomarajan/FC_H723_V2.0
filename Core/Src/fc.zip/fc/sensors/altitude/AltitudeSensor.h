#ifndef _BAROCOMMON_H_
#define _BAROCOMMON_H_

#include <sys/_stdint.h>


//Altitude estimate Complementary filter alpha
#define SENSOR_ALT_ESTIMATE_ALPHA  0.995f    // Greater means more sensitive to vertical vel
#define SENSOR_ALT_ESTIMATE_ONE_MINUS_ALPHA  (1.0f - SENSOR_ALT_ESTIMATE_ALPHA)
#define SENSOR_ALT_ESTIMATE_VEL_GAIN  10.0f  //cm/sec

#define SENSOR_ALT_BARO_LPF_FREQUENCY  0.85f   //1.25f-Highest resolution //0.85f -//Std Resolution
#define SENSOR_ALT_BARO_ALTITUDE_GAIN  100.0f  //In CMS // Output in meters

/* Vertical Velocity configurations */
#define SENSOR_ALT_VERTICAL_VELOCITY_DEADBAND     0.0f   // Meter/Sec
#define SENSOR_ALT_VERTICAL_VELOCITY_OUTPUT_GAIN  100.0f  //cm/sec
#define SENSOR_ALT_VERTICAL_VELOCITY_MAX          30.0f   // cm/Sec
#define SENSOR_ALT_VERTICAL_VELOCITY_LPF_FREQ     100.00f

typedef struct _SENSOR_ALTITUDE_DATA SENSOR_ALTITUDE_DATA;
struct _SENSOR_ALTITUDE_DATA {
	float altitudeSL;
	float altitudeSLScaled;
	float altitudeSLFiltered;
	float altitudeSLEstimated;
	float verticalVelocity;
	float altDataUpdateDt;
	float altProcessDt;
};

extern SENSOR_ALTITUDE_DATA sensorAltitudeData;

uint8_t initAltitudeSensors(void);
uint8_t readAltitudeSensors(void);
uint8_t loadAltitudeSensorsData(void);
void updateAltitude(float dt);
void processAltitude(float dt, float altitudeBias);
void resetAltitudeSensors(uint8_t hard);

#endif /* FC_FCDEVICES_INCLUDE_BAROCOMMON_H_ */
