#include "AltitudeDevice.h"

DEVICE_ALTITUDE_DATA deviceAltitudeData;


