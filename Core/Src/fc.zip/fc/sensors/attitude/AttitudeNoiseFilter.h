#ifndef SRC_FC_SENSORS_ATTITUDE_ATTITUDENOISEFILTER_H_
#define SRC_FC_SENSORS_ATTITUDE_ATTITUDENOISEFILTER_H_
#include <stdint.h>
#include "../../dsp/FFT.h"

/* -----------------------------------------------------------
 * 🔄 Filter Settings & Noise Filtering
 * -----------------------------------------------------------*/

/* --- Gyro FFT Configurations --- */
#define SENSOR_FFT_GYRO_ENABLED                 1
#define SENSOR_FFT_GYRO_FREQUENCY_N             FFT_TOP_FREQ_N
#define SENSOR_FFT_GYRO_FILTER_HARMONICS_FIRST  0   // Filtration starts from harmonics to fundamental

#define SENSOR_FFT_NTF_GYRO_MIN_CUTOFF_FREQUENCY  50.0f
#define SENSOR_FFT_NTF_GYRO_MAX_CUTOFF_FREQUENCY  600.0f

#define SENSOR_FFT_NTF_GYRO_GAIN                1.0f

#define FFT_PROCESSING_BUDGET 64
/*
 *
 * Higher Q: The filter is narrower, targets the noise more precisely.
 * Lower Q: The filter is wider, covering a broader frequency range but adding more latency,
 *
 */
//#define SENSOR_FFT_NTF_GYRO_Q                 {0.915f,0.815f,0.715f} //{0.915f,0.815f,0.715f} // {0.8f, 1.2f, 1.6f} //{0.77f,1.0f,1.2f}
#define SENSOR_FFT_NTF_GYRO_Q                   {0.65f,0.85f}

#define SENSOR_FFT_NTF_CF_LPF_FREQUENCY         10.0f
#define SENSOR_FFT_NTF_CF_DELTA_THRESHOLD       5.0f

/* --- ACC LPF Configurations --- */
#define SENSOR_LPF_STD_ACC_ENABLED              1
#define SENSOR_LPF_STD_ACC_FREQUENCY            25.0f

/* --- Gyro LPF Configurations --- */
#define SENSOR_LPF_STD_GYRO_ENABLED             1
#define SENSOR_LPF_STD_GYRO_FREQUENCY           272.0f

/* --- Magnetometer & Temperature LPF Configurations --- */
#define SENSOR_LPF_MAG_FREQUENCY                5.0f
#define SENSOR_LPF_TEMP_FREQUENCY               2.0f

// ===== Noise Update / Filtering =====
void updateNoiseFilterData(float dt);
void updateNoiseFilterCoefficients();

void filterAGTNoise(float dt);
void filterMagNoise(float dt);

// ===== Temperature Correction =====
void calculateTempCorrectionOffsets(float currentTemp);
// ===== Noise Sensor Init / Reset =====
uint8_t initAttitudeNoiseFilter(float accSampleFrequency, float gyroSampleFrequency, float magSampleFrequency, float tempSampleFrequency);

void resetNoiseFilter(void);

#endif /* SRC_FC_SENSORS_ATTITUDE_ATTITUDENOISEFILTER_H_ */
