#include "AttitudeDevice.h"
DEVICE_ATTITUDE_DATA __ATTR_DTCM_BSS deviceAttitudeData;
